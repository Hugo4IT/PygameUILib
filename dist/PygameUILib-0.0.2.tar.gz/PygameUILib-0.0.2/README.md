# PygameUILib by Hugo4IT
### WORK IN PROGRESS, PLEASE DONT USE YET
#### Please go to bottom of the page for progress info
A simple, fast GUI solution for Pygame

For progress info or submissions of ideas/elements, click [Here](https://trello.com/b/9dwC0kAZ/pygameuilib-pygameanimationlib)

## Installation:
- #### Windows
  - Open command prompt
  - Enter `pip install PygameUILib`
  - Done
- #### Windows (Super beginner)
  - Copy this text: `pip install PygameUILib`
  - Press `Windows Icon` + `R`
  - Type `cmd`
  - Hit `Enter ↵`
  - A black window should have popped up
  - Right click on the black window
  - Hit `Enter ↵`
  - Done
- #### Linux/MacOS:
  - Open the app `Terminal` (Name may vary when using linux)
  - Enter `pip install PygameUILib`
  - Done

## How to use/Documentation
Take a look at the documentation and a beginner guide on my [Website](https://Hugo4IT.com/PygameUILib)

For progress info or submissions of ideas/elements, click [Here](https://trello.com/b/9dwC0kAZ/pygameuilib-pygameanimationlib)
